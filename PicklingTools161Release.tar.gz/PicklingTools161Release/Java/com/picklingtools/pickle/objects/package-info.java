/**
 * Object constructors and other utility classes for the pickle package.
 * 
 * @author Irmen de Jong (irmen@razorvine.net)
 * @version 1.4
 * @see pickle
 */
package pickle.objects;
